﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using LoginFunctionalityDAL;

namespace LoginFuncationality_BAL
{
    public class LoginBAL
    {
        UserValOutput objUserValOP = new UserValOutput();
        LoginDAL objDAL = new LoginDAL();
        int check;
        public UserValOutput ValidateUser(LoginEntity objLE)
        {
            objUserValOP = objDAL.ValidateUserDAL(objLE);
            return objUserValOP;
        }

        public int CreateUser(UserRegistration objUserReg)
        {
            check = objDAL.CreateUser(objUserReg);
            return check;
        }


    }
}       
