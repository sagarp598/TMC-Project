﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using LoginFunctionalityDAL;

namespace LoginFuncationality_BAL
{
    public class BookingBAL
    {
        List<string> lstActivity = new List<string>();
        List<string> lstCategory = new List<string>();
        BookingDAL objDAL = new BookingDAL();

        public List<string> GetActivityBAL(string dayName)
        {
            lstActivity = objDAL.GetActivityDAL(dayName);
            return lstActivity;
        }

        public List<string> GetCategoryBAL(string activityName,string dayName)
        {
            lstCategory = objDAL.GetCategoryDAL(activityName,dayName);
            return lstCategory;
        }

        public List<BookingStatusView> GrdBookingStatusBAL(ActivityMaster objAM)
        {
            List<BookingStatusView> lstBookingStat = new List<BookingStatusView>();

            lstBookingStat = objDAL.GrdBookingStatusDAL(objAM);

            return lstBookingStat;

        }

        public List<BookingStatusView> GrdViewRequestsBAL(int _userid)
        {
            List<BookingStatusView> lstBookingStat = new List<BookingStatusView>();

            lstBookingStat = objDAL.GrdViewRequestsDAL(_userid);

            return lstBookingStat;

        }

        public int GetActivityIdBAL(ActivityMaster objAM)
        {
            int _activityid;
            _activityid = objDAL.GetActivityIdDAL(objAM);
            return _activityid;

        }

        public int CreateBookingBAL(CreateBooking objCB)
        {
            int flag;
            flag = objDAL.CreateBookingDAL(objCB);
            return flag;
        }


        public int CancelBookingBAL(int _bookingid)
        {
            int flag;
            flag = objDAL.CancelBookingDAL(_bookingid);
            return flag;
        }

    }
}
