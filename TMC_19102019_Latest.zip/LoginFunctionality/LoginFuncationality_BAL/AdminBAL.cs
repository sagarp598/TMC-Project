﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using LoginFunctionalityDAL;

namespace LoginFuncationality_BAL
{
    public class AdminBAL
    {
        List<GetAllVIP> lstVIP = new List<GetAllVIP>();
        AdminDAL objDAL = new AdminDAL();

        public List<GetAllVIP> GetAllVIPBAL()
        {
            lstVIP = objDAL.GetAllVIPDAL();
            return lstVIP;
        }

        /*
                public List<string> GetCategoryBAL(string activityName,string dayName)
                {
                    lstCategory = objDAL.GetCategoryDAL(activityName,dayName);
                    return lstCategory;
                }

                public List<BookingStatusView> GrdBookingStatusBAL(ActivityMaster objAM)
                {
                    List<BookingStatusView> lstBookingStat = new List<BookingStatusView>();

                    lstBookingStat = objDAL.GrdBookingStatusDAL(objAM);

                    return lstBookingStat;

                } */

        public List<AdminStatusView> AdminViewRequestsBAL()
        {
            List<AdminStatusView> lstAdminReq = new List<AdminStatusView>();

            lstAdminReq = objDAL.AdminViewRequestsDAL();

            return lstAdminReq;

        }

        
        public int UpdateRequestBAL(AdminStatusView objASV)
        {
            int flag;
            flag = objDAL.UpdateRequestDAL(objASV);
            return flag;

        }
        /*
                public int CreateBookingBAL(CreateBooking objCB)
                {
                    int flag;
                    flag = objDAL.CreateBookingDAL(objCB);
                    return flag;
                }


                public int CancelBookingBAL(int _bookingid)
                {
                    int flag;
                    flag = objDAL.CancelBookingDAL(_bookingid);
                    return flag;
                }
                */

    }
}
