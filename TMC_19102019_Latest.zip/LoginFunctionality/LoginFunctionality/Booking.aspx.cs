﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginFuncationality_BAL;
using BusinessEntityDLL;


namespace LoginFunctionality
{
    public partial class Booking : System.Web.UI.Page
    {
        BookingBAL objBAL = new BookingBAL();
        public string dayName;
        public int _userid;
        public int _isAdmin;
        protected void Page_Load(object sender, EventArgs e)
        {
            calBookingDate.VisibleDate = DateTime.Now.AddMonths(1);
            _userid = Convert.ToInt32(Request.QueryString["uid"]);
            _isAdmin = Convert.ToInt32(Request.QueryString["ad"]);

            if (!IsPostBack)
            {
                GRChkAvailability();
            }

        }
        protected void btnCheckAvailability_Click(object sender, EventArgs e)
        {
            grvViewReq.Visible = false;
            grvChkAvailability.Visible = true;
            GRChkAvailability();
        }

        protected void imgbtnCalender_Click(object sender, ImageClickEventArgs e)
        {
            calBookingDate.Visible = true;

        }

        protected void calBookingDate_SelectionChanged(object sender, EventArgs e)
        {
            txtCalender.Text = calBookingDate.SelectedDate.Date.ToShortDateString();
            calBookingDate.Visible = false;
            dayName = calBookingDate.SelectedDate.DayOfWeek.ToString();

            List<string> lstActivity = new List<string>();
           
            lstActivity = objBAL.GetActivityBAL(dayName);
            ddlActivity.DataSource = lstActivity;
            ddlActivity.DataBind();
            ddlActivity.Items.Insert(0,"--Select--");



            lblDate.Text = dayName;
        }

        protected void calBookingDate_DayRender(object sender, DayRenderEventArgs e)
        {
            DateTime pastday = e.Day.Date;
        DateTime date = DateTime.Now;
        int year = date.Year;
        int month = date.Month;
        int day = date.Day;
        DateTime today = new DateTime(year, month, day);
            if (_isAdmin == 0)
            {
                if (pastday.CompareTo(today.AddMonths(1)) < 0)
                {
                    e.Cell.BackColor = System.Drawing.Color.Gray;
                    e.Day.IsSelectable = false;
                }
            }
            else
            {
                if (pastday.CompareTo(today) < 0)
                {
                    e.Cell.BackColor = System.Drawing.Color.Gray;
                    e.Day.IsSelectable = false;
                }
            }


        }
        


        protected void ddlActivity_SelectedIndexChanged(object sender, EventArgs e)
        {
            List<string> lstCategory = new List<string>();
           
            lstCategory = objBAL.GetCategoryBAL(ddlActivity.SelectedValue.ToString(), Convert.ToDateTime(txtCalender.Text).DayOfWeek.ToString());
            ddlCategory.DataSource = lstCategory;
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0,"--Select--");
        }

        public void GRChkAvailability()
        {
            ActivityMaster objActivityMaster = new ActivityMaster();
            List<BookingStatusView> lstBSV = new List<BookingStatusView>();
            objActivityMaster.Activityname = ddlActivity.SelectedValue.ToString();
            objActivityMaster.Categoryname = ddlCategory.SelectedValue.ToString();
            objActivityMaster.SelectedDate = calBookingDate.SelectedDate.ToShortDateString();

            lstBSV = objBAL.GrdBookingStatusBAL(objActivityMaster);

            grvChkAvailability.DataSource = lstBSV;
            grvChkAvailability.DataBind();


        }

        public void GRViewRequestStatus()
        {
            
            List<BookingStatusView> lstBSV = new List<BookingStatusView>();
            
            lstBSV = objBAL.GrdViewRequestsBAL(_userid);

            grvViewReq.DataSource = lstBSV;
            grvViewReq.DataBind();


        }



        protected void grvChkAvailability_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvChkAvailability.EditIndex = e.NewEditIndex;
             GRChkAvailability();
            
            
        }

        protected void grvChkAvailability_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int flag;
            BusinessEntityDLL.CreateBooking objCB = new BusinessEntityDLL.CreateBooking();
            ActivityMaster objAM = new ActivityMaster();
            objAM.Activityname = (grvChkAvailability.Rows[e.RowIndex].Cells[0].Controls[0] as TextBox).Text;
            objAM.Categoryname = (grvChkAvailability.Rows[e.RowIndex].Cells[1].Controls[0] as TextBox).Text;
            objAM.Timeslot = (grvChkAvailability.Rows[e.RowIndex].Cells[2].Controls[0] as TextBox).Text;
            objAM.Availableforday  = calBookingDate.SelectedDate.DayOfWeek.ToString();


            objCB.UserId = _userid;
            objCB.ActivityId  = objBAL.GetActivityIdBAL(objAM);
            objCB.QuantityNo = Convert.ToInt32((grvChkAvailability.Rows[e.RowIndex].Cells[3].Controls[0] as TextBox).Text);
            objCB.BookingDate = calBookingDate.SelectedDate.Date.ToShortDateString();

            if (_isAdmin == 0) { objCB.BookingStatus = "Pending"; }
            else { objCB.BookingStatus = "Approved"; };

            objCB.BookingUpdatedBy = _userid.ToString();

            flag = objBAL.CreateBookingBAL(objCB);
            if (flag == 0)
                lblBookingStatus.Text = "Request Succesfully placed for " + calBookingDate.SelectedDate.Date.ToShortDateString() + " for selected activity.";

            grvChkAvailability.EditIndex = -1;
            GRChkAvailability();
        }

        protected void grvChkAvailability_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string _bookingStatus;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.RowIndex == grvChkAvailability.EditIndex)
                {
                    _bookingStatus = (e.Row.Cells[6].Controls[0] as TextBox).Text;
                }
                else
                {
                    _bookingStatus = e.Row.Cells[6].Text;
                }


                    if (_bookingStatus != "AVAILABLE")
                    {
                        e.Row.Enabled = false;
                    }

                } 
        }

        protected void btnVReq_Click(object sender, EventArgs e)
        {
            grvViewReq.Visible = true;
            grvChkAvailability.Visible = false;
            GRViewRequestStatus();
        }

        protected void grvViewReq_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvViewReq.EditIndex = e.NewEditIndex;
            GRViewRequestStatus();
        }

        protected void grvViewReq_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int _bookingid,flag;
            _bookingid = Convert.ToInt32( grvViewReq.Rows[e.RowIndex].Cells[0].Text);
            flag = objBAL.CancelBookingBAL(_bookingid);

            if (flag == 0)
                lblBookingStatus.Text = "Booking deleted successfully.";
            else
                lblBookingStatus.Text = "Contact admin.";

            grvViewReq.EditIndex = -1;
            GRViewRequestStatus();
        }

        protected void grvViewReq_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grvViewReq.EditIndex = -1;
            GRViewRequestStatus();
        }

        protected void grvChkAvailability_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grvChkAvailability.EditIndex = -1;
            GRChkAvailability();
        }
    }
}