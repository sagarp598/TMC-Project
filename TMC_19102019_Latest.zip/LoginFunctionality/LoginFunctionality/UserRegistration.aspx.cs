﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BusinessEntityDLL;
using LoginFuncationality_BAL;

namespace LoginFunctionality
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        BusinessEntityDLL.UserRegistration objUserReg = new BusinessEntityDLL.UserRegistration();
        LoginBAL objLoginBal = new LoginBAL();
        int flag;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ddlCustType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCustType.SelectedValue.ToString() == "--Select--")
            {
                txtInstitutionName.Enabled = false;
                txtContPerName.Enabled = false;


                ddlSalutation.Enabled = false; txtFname.Enabled = false; txtLname.Enabled = false;
            }
            else if (ddlCustType.SelectedValue.ToString() == "Institution")
            {
                 txtInstitutionName.Enabled = true;
                 txtContPerName.Enabled = true;

                
                ddlSalutation.Enabled = false; txtFname.Enabled = false; txtLname.Enabled = false;
            }
            else
            {
                
                ddlSalutation.Enabled = true;txtFname.Enabled = true;txtLname.Enabled = true;
                txtInstitutionName.Enabled = false;
                txtContPerName.Enabled = false;
            }
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            objUserReg.Username = txtUsername.Text;
            objUserReg.Password = txtPassword.Text;
            objUserReg.Salutation = ddlSalutation.SelectedValue.ToString();
            objUserReg.Fname = txtFname.Text;
            objUserReg.Lname = txtLname.Text;
            objUserReg.Institutionname = txtInstitutionName.Text;
            objUserReg.Contactpersonname = txtContPerName.Text;
            objUserReg.Custtype = ddlCustType.SelectedValue.ToString();
            objUserReg.Emailid = txtEmailid.Text;
            objUserReg.Contactno = txtContno.Text;
            objUserReg.Mobileno = txtMobileno.Text;
            objUserReg.Address = txtAddress.Text;
            objUserReg.City = txtCity.Text;
            objUserReg.Pincode = Convert.ToInt32(txtPincode.Text);
            objUserReg.IsAdmin = false;
            objUserReg.IsVIP = false;
            objUserReg.Designation = "Registered User";

            flag = objLoginBal.CreateUser(objUserReg);

            if (flag == 0)
            {
                lblStatus.Text = "User Resgistration is successful!!";
                Reset();
            }
            else
            {
                lblStatus.Text = "User Resgistration is failed.Contact System Admin.";
                Reset();
            }
        }

        public void Reset()
        {
            txtUsername.Text = "";
            txtPassword.Text = "";
            ddlSalutation.SelectedIndex = 0;
            txtFname.Text = "";
            txtLname.Text = "";
            txtInstitutionName.Text = "";
            txtContPerName.Text = "";
            ddlCustType.SelectedIndex = 0;
            txtEmailid.Text = "";
            txtContno.Text = "";
            txtMobileno.Text = "";
            txtAddress.Text = "";
            txtCity.Text = "";
            txtPincode.Text = "";
            txtConfirmPwd.Text = "";
            
            
        }

    }
}