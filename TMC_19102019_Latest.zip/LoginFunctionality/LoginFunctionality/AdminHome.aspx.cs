﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginFuncationality_BAL;
using BusinessEntityDLL;

namespace LoginFunctionality
{
    public partial class AdminHome : System.Web.UI.Page
    {
        AdminBAL objBAL = new AdminBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                GRViewRequestStatus();
        }

        protected void btnChkReq_Click(object sender, EventArgs e)
        {
            GRViewRequestStatus();
        }

        public void GRViewRequestStatus()
        {

            List<AdminStatusView> lstBSV = new List<AdminStatusView>();

            lstBSV = objBAL.AdminViewRequestsBAL();

            grvViewAdminReq.DataSource = lstBSV;
            grvViewAdminReq.DataBind();


        }

   /*     protected void grvViewAdminReq_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            AdminStatusView objASV = new AdminStatusView();
            int flag;
            if (e.CommandName == "Approve")
            {

                objASV.BookingId = Convert.ToInt32(grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[0].Text);
                objASV.Remarks = "Request has been approved.";
                objASV.BookingUpdatedBy = Convert.ToInt32(Session["userid"].ToString());
                objASV.BookingStatus = "Approved";

                flag = objBAL.UpdateRequestBAL(objASV);
                if (flag == 0)
                {
                    lblStatus.Text = "Action done";
                }
                else
                {
                    lblStatus.Text = "Contact Admin";

                }
                GRViewRequestStatus();
            }

            if(e.CommandName == "Edit")
            {
                //   (grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].FindControl("txtRemarks") as TextBox).Enabled = true;
                // (grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].FindControl("rfvReq") as RequiredFieldValidator).Enabled = true;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[0].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[1].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[2].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[3].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[4].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[5].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[6].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[7].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[8].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[9].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[10].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[11].Enabled = false;
                grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[12].Enabled = true;

                objASV.BookingId = Convert.ToInt32(grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[0].Text);
                objASV.Remarks = (grvViewAdminReq.Rows[Convert.ToInt32(e.CommandArgument)].Cells[12].FindControl("txtRemarks") as TextBox).Text;
                objASV.BookingUpdatedBy = Convert.ToInt32(Session["userid"].ToString());
                objASV.BookingStatus = "Rejected";

                flag = objBAL.UpdateRequestBAL(objASV);
                if (flag == 0)
                {
                    lblStatus.Text = "Action done";
                }
                else
                {
                    lblStatus.Text = "Contact Admin";

                }
                GRViewRequestStatus();
            }
        }

        protected void grvViewAdminReq_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            /*string _bookingStatus;
           _bookingStatus = e.Row.Cells[11].Text;
            
            

                if (_bookingStatus != "Pending")
                {
                    e.Row.Enabled = false;
                }
           // e.Row.Cells[12].Enabled = false;
            


        }*/

        protected void grvViewAdminReq_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvViewAdminReq.EditIndex = e.NewEditIndex;
            GRViewRequestStatus();
        }

        protected void grvViewAdminReq_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            AdminStatusView objASV = new AdminStatusView();
            int flag;
           
                objASV.BookingId = Convert.ToInt32((grvViewAdminReq.Rows[e.RowIndex].Cells[0].Controls[0] as TextBox).Text);
                objASV.Remarks = "Request has been approved.";
                objASV.BookingUpdatedBy = Convert.ToInt32(Session["userid"].ToString());
                objASV.BookingStatus = "Approved";

                flag = objBAL.UpdateRequestBAL(objASV);
                if (flag == 0)
                {
                    lblStatus.Text = "Action done";
                }
                else
                {
                    lblStatus.Text = "Contact Admin";

                }
            grvViewAdminReq.EditIndex = -1;
                GRViewRequestStatus();
            

        }

        protected void grvViewAdminReq_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            AdminStatusView objASV = new AdminStatusView();
            int flag;

            objASV.BookingId = Convert.ToInt32((grvViewAdminReq.Rows[e.RowIndex].Cells[0].Controls[0] as TextBox).Text);
            objASV.Remarks = "Request Rejected. " + (grvViewAdminReq.Rows[e.RowIndex].Cells[12].Controls[0] as TextBox).Text;
            objASV.BookingUpdatedBy = Convert.ToInt32(Session["userid"].ToString());
            objASV.BookingStatus = "Rejected";

            flag = objBAL.UpdateRequestBAL(objASV);
            if (flag == 0)
            {
                lblStatus.Text = "Action done";
            }
            else
            {
                lblStatus.Text = "Contact Admin";

            }
            grvViewAdminReq.EditIndex = -1;
            GRViewRequestStatus();

        }

        protected void grvViewAdminReq_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string _bookingStatus;
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (e.Row.RowIndex == grvViewAdminReq.EditIndex)
                {
                    (e.Row.Cells[0].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[1].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[2].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[3].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[4].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[5].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[6].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[7].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[8].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[9].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[10].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[11].Controls[0] as TextBox).Enabled = false;
                    (e.Row.Cells[12].Controls[0] as TextBox).Enabled = true;
                    _bookingStatus = (e.Row.Cells[11].Controls[0] as TextBox).Text;

                }
                else
                {
                    _bookingStatus = e.Row.Cells[11].Text;
                }

                if (_bookingStatus != "Pending")
                {
                    e.Row.Enabled = false;
                }

            }
        }

        protected void grvViewAdminReq_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvViewAdminReq.PageIndex = e.NewPageIndex;
            GRViewRequestStatus();
        }
    }
}