﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class UserValOutput
    {

        private int _flag;
        private int _userid;
        private bool _isadmin;
        public int flag
        {
            get { return _flag; }
            set { _flag = value; }
        }
        public int userid
        {
            get { return _userid; }
            set { _userid = value; }
        }
        public bool isadmin
        {
            get { return _isadmin; }
            set { _isadmin = value; }
        }

    }
}
