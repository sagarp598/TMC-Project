﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class UserRegistration
    {

        private string _username;
        private string _password;
        private string _salutation;
        private string _fname;
        private string _lname;
        private string _institutionname;
        private string _contactpersonname;
        private string _custtype;
        private string _emailid;
        private string _contactno;
        private string _mobileno;
        private string _address;
        private string _city;
        private int _pincode;
        private bool _isAdmin;
        private bool _isVIP;
        private string _designation;

        public string Designation
        {
            get { return _designation; }
            set { _designation = value; }
        }
        public string Username {
            get { return _username; }
            set { _username = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string Salutation
        {
            get { return _salutation; }
            set { _salutation = value; }
        }

        public string Fname
        {
            get { return _fname; }
            set { _fname = value; }
        }

        public string Lname
        {
            get { return _lname; }
            set { _lname = value; }
        }

        public string Institutionname
        {
            get { return _institutionname; }
            set { _institutionname = value; }
        }

        public string Contactpersonname
        {
            get { return _contactpersonname; }
            set { _contactpersonname = value; }
        }

        public string Custtype
        {
            get { return _custtype; }
            set { _custtype = value; }
        }

        public string Emailid
        {
            get { return _emailid; }
            set { _emailid = value; }
        }

        public string Contactno
        {
            get { return _contactno; }
            set { _contactno = value; }
        }

        public string Mobileno
        {
            get { return _mobileno; }
            set { _mobileno = value; }
        }

        public string Address
        {
            get { return _address; }
            set { _address = value; }
        }

        public string City
        {
            get { return _city; }
            set { _city = value; }
        }

        public int Pincode
        {
            get { return _pincode; }
            set { _pincode = value; }
        }

        public bool IsAdmin
        {
            get { return _isAdmin; }
            set { _isAdmin = value; }
        }

        public bool IsVIP
        {
            get { return _isVIP; }
            set { _isVIP = value; }
        }
    }
}
