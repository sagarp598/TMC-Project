﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace LoginFunctionalityDAL
{
    public class AdminDAL
    {

        List<GetAllVIP> lstVIP = new List<GetAllVIP>();
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public List<GetAllVIP> GetAllVIPDAL()
        {
            SqlCommand objCmd = new SqlCommand("sp_getallvip", objCon);
            
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Connection = objCon;
            objCon.Open();
            SqlDataReader objDr = objCmd.ExecuteReader();

            while (objDr.Read())
            {
                GetAllVIP objVIP = new GetAllVIP();
                objVIP.VIPName = Convert.ToString(objDr["name"]);
                objVIP.UserId = Convert.ToInt32(objDr["userid"]);

                lstVIP.Add(objVIP);
            }
            objCon.Close();
            return lstVIP;
        }

        /* public List<string> GetCategoryDAL(string activityname,string dayName)
         {
             SqlCommand objCmd = new SqlCommand("sp_getcategory", objCon);

             objCmd.CommandType = CommandType.StoredProcedure;
             objCmd.Parameters.AddWithValue("@activtyname", activityname);
             objCmd.Parameters.AddWithValue("@dayname", dayName);
             objCmd.Connection = objCon;
             objCon.Open();
             SqlDataReader objDr = objCmd.ExecuteReader();

             while (objDr.Read())
             {
                 lstCategory.Add(Convert.ToString(objDr["categoryname"]));
             }
             objCon.Close();
             return lstCategory;
         }

         public List<BookingStatusView> GrdBookingStatusDAL(ActivityMaster objAM)
         {
             List<BookingStatusView> lstBookingStat = new List<BookingStatusView>();

             SqlCommand objCmd = new SqlCommand("sp_chkavailabilitystatus", objCon);

             objCmd.CommandType = CommandType.StoredProcedure;
             objCmd.Parameters.AddWithValue("@activityname", objAM.Activityname);
             objCmd.Parameters.AddWithValue("@categoryname", objAM.Categoryname);
             objCmd.Parameters.AddWithValue("@bookingdate", objAM.SelectedDate);

             objCmd.Connection = objCon;
             objCon.Open();
             SqlDataReader objDr = objCmd.ExecuteReader();

             while (objDr.Read())
             {
                 BookingStatusView objBSV = new BookingStatusView();
                 objBSV.Activityname = Convert.ToString(objDr["activityname"]);
                 objBSV.Categoryname = Convert.ToString(objDr["categoryname"]);
                 objBSV.Timeslot = Convert.ToString(objDr["timeslot"]);
                 objBSV.BookingDate = Convert.ToString(objDr["bookingdate"]);
                 objBSV.Quantityno =  Convert.ToInt32(objDr["quantityno"]);
                 objBSV.BookingStatus = Convert.ToString(objDr["BookingStatus"]);
                 objBSV.BookingPlacedDate = Convert.ToString(objDr["bookingcreateddate"]);

                 lstBookingStat.Add(objBSV);
             }

             objCon.Close();
             return lstBookingStat;

         }
         */

        public List<AdminStatusView> AdminViewRequestsDAL()
        {
            List<AdminStatusView> lstAdminReq = new List<AdminStatusView>();

            SqlCommand objCmd = new SqlCommand("sp_getallrequests", objCon);

            objCmd.CommandType = CommandType.StoredProcedure;
         //   objCmd.Parameters.AddWithValue("@userid", _userid);

            objCmd.Connection = objCon;
            objCon.Open();
            SqlDataReader objDr = objCmd.ExecuteReader();

            while (objDr.Read())
            {
                AdminStatusView objASV = new AdminStatusView();

                objASV.BookingId = Convert.ToInt32(objDr["booking_id"]);

                objASV.Requester = Convert.ToString(objDr["requester"]);
                objASV.EmailId = Convert.ToString(objDr["emailid"]);
                objASV.MobileNo = Convert.ToString(objDr["mobileno"]);
                objASV.ContactNo = Convert.ToString(objDr["contactno"]);

                objASV.Activityname = Convert.ToString(objDr["activityname"]);
                objASV.Categoryname = Convert.ToString(objDr["categoryname"]);
                objASV.Timeslot = Convert.ToString(objDr["timeslot"]);
                objASV.BookingDate = Convert.ToString(objDr["bookingdate"]);
                objASV.Quantityno = Convert.ToInt32(objDr["quantityno"]);
                objASV.BookingStatus = Convert.ToString(objDr["BookingStatus"]);
                objASV.BookingPlacedDate = Convert.ToString(objDr["bookingcreateddate"]);
                objASV.Remarks = Convert.ToString(objDr["remarks"]);

                lstAdminReq.Add(objASV);
            }

            objCon.Close();
            return lstAdminReq;

        }


       public int UpdateRequestDAL(AdminStatusView objASV)
        {
            int flag;
            SqlCommand objCmd = new SqlCommand("sp_updatereqstatus", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@decision", objASV.BookingStatus);
            objCmd.Parameters.AddWithValue("@updatedby", objASV.BookingUpdatedBy);
            objCmd.Parameters.AddWithValue("@remarks", objASV.Remarks);
            objCmd.Parameters.AddWithValue("@bookingid", objASV.BookingId);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;

            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);
            objCon.Close();
            return flag;
        }

        /*  public int GetActivityIdDAL(ActivityMaster objAM)
         {
             int _activityid;
             SqlCommand objCmd = new SqlCommand("sp_getactivityid", objCon);
             objCmd.CommandType = CommandType.StoredProcedure;
             objCmd.Parameters.AddWithValue("@activityname", objAM.Activityname);
             objCmd.Parameters.AddWithValue("@categoryname", objAM.Categoryname);
             objCmd.Parameters.AddWithValue("@timeslot", objAM.Timeslot);
             objCmd.Parameters.AddWithValue("@dayname", objAM.Availableforday);

             objCmd.Parameters.Add("@activityid", SqlDbType.Int);
             objCmd.Parameters["@activityid"].Direction = ParameterDirection.Output;

             objCmd.Connection = objCon;
             objCon.Open();
             int i = objCmd.ExecuteNonQuery();
             _activityid = Convert.ToInt32(objCmd.Parameters["@activityid"].Value);
             objCon.Close();
             return _activityid;
                     }

         public int CancelBookingDAL(int _bookingid)
         {
             int flag;
             SqlCommand objCmd = new SqlCommand("sp_cancelbooking", objCon);
             objCmd.CommandType = CommandType.StoredProcedure;
             objCmd.Parameters.AddWithValue("@bookingid", _bookingid);

             objCmd.Parameters.Add("@flag", SqlDbType.Int);
             objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;

             objCmd.Connection = objCon;
             objCon.Open();
             int i = objCmd.ExecuteNonQuery();
             flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);
             objCon.Close();
             return flag;
         }*/

    }
}
