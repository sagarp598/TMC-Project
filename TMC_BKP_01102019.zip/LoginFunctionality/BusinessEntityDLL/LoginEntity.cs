﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class LoginEntity
    {
        private string _userName;
        private string _password;
        public string userName
        {
            get { return _userName; }
            set { _userName = value; }
        }
        public string password
        {
            get { return _password; }
            set { _password = value; }
        }
    }
}

