﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace LoginFunctionalityDAL
{
    public class BookingDAL
    {

        List<string> lstActivity = new List<string>();
        List<string> lstCategory = new List<string>();
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);

        public List<string> GetActivityDAL(string dayName)
        {
            SqlCommand objCmd = new SqlCommand("sp_getactivity", objCon);
            
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@dayname", dayName);
            objCmd.Connection = objCon;
            objCon.Open();
            SqlDataReader objDr = objCmd.ExecuteReader();

            while (objDr.Read())
            {
                lstActivity.Add(Convert.ToString(objDr["activityname"]));
            }
            objCon.Close();
            return lstActivity;
        }

        public List<string> GetCategoryDAL(string activityname,string dayName)
        {
            SqlCommand objCmd = new SqlCommand("sp_getcategory", objCon);

            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@activtyname", activityname);
            objCmd.Parameters.AddWithValue("@dayname", dayName);
            objCmd.Connection = objCon;
            objCon.Open();
            SqlDataReader objDr = objCmd.ExecuteReader();

            while (objDr.Read())
            {
                lstCategory.Add(Convert.ToString(objDr["categoryname"]));
            }
            objCon.Close();
            return lstCategory;
        }

        public List<BookingStatusView> GrdBookingStatusDAL(ActivityMaster objAM)
        {
            List<BookingStatusView> lstBookingStat = new List<BookingStatusView>();

            SqlCommand objCmd = new SqlCommand("sp_chkavailabilitystatus", objCon);

            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@activityname", objAM.Activityname);
            objCmd.Parameters.AddWithValue("@categoryname", objAM.Categoryname);
            objCmd.Parameters.AddWithValue("@bookingdate", objAM.SelectedDate);

            objCmd.Connection = objCon;
            objCon.Open();
            SqlDataReader objDr = objCmd.ExecuteReader();

            while (objDr.Read())
            {
                BookingStatusView objBSV = new BookingStatusView();
                objBSV.Activityname = Convert.ToString(objDr["activityname"]);
                objBSV.Categoryname = Convert.ToString(objDr["categoryname"]);
                objBSV.Timeslot = Convert.ToString(objDr["timeslot"]);
                objBSV.BookingDate = Convert.ToString(objDr["bookingdate"]);
                objBSV.Quantityno =  Convert.ToInt32(objDr["quantityno"]);
                objBSV.BookingStatus = Convert.ToString(objDr["BookingStatus"]);
                objBSV.BookingPlacedDate = Convert.ToString(objDr["bookingcreateddate"]);
               
                lstBookingStat.Add(objBSV);
            }

            objCon.Close();
            return lstBookingStat;

        }


        public List<BookingStatusView> GrdViewRequestsDAL(int _userid)
        {
            List<BookingStatusView> lstBookingStat = new List<BookingStatusView>();

            SqlCommand objCmd = new SqlCommand("sp_viewrequeststatus", objCon);

            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@userid", _userid);

            objCmd.Connection = objCon;
            objCon.Open();
            SqlDataReader objDr = objCmd.ExecuteReader();

            while (objDr.Read())
            {
                BookingStatusView objBSV = new BookingStatusView();
                objBSV.BookingId = Convert.ToInt32(objDr["booking_id"]);
                objBSV.Activityname = Convert.ToString(objDr["activityname"]);
                objBSV.Categoryname = Convert.ToString(objDr["categoryname"]);
                objBSV.Timeslot = Convert.ToString(objDr["timeslot"]);
                objBSV.BookingDate = Convert.ToString(objDr["bookingdate"]);
                objBSV.Quantityno = Convert.ToInt32(objDr["quantityno"]);
                objBSV.BookingStatus = Convert.ToString(objDr["BookingStatus"]);
                objBSV.BookingPlacedDate = Convert.ToString(objDr["bookingcreateddate"]);
                objBSV.Remarks = Convert.ToString(objDr["remarks"]);
                lstBookingStat.Add(objBSV);
            }

            objCon.Close();
            return lstBookingStat;

        }


        public int CreateBookingDAL(CreateBooking objCB)
        {
            int flag;
            SqlCommand objCmd = new SqlCommand("sp_createbooking", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@user_id", objCB.UserId);
            objCmd.Parameters.AddWithValue("@activity_id", objCB.ActivityId);
            objCmd.Parameters.AddWithValue("@quantityno", objCB.QuantityNo);
            objCmd.Parameters.AddWithValue("@bookingdate", objCB.BookingDate);
            objCmd.Parameters.AddWithValue("@bookingstatus", objCB.BookingStatus);
            objCmd.Parameters.AddWithValue("@bookingupdatedby", objCB.BookingUpdatedBy);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;

            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);
            objCon.Close();
            return flag;
        }

        public int GetActivityIdDAL(ActivityMaster objAM)
        {
            int _activityid;
            SqlCommand objCmd = new SqlCommand("sp_getactivityid", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@activityname", objAM.Activityname);
            objCmd.Parameters.AddWithValue("@categoryname", objAM.Categoryname);
            objCmd.Parameters.AddWithValue("@timeslot", objAM.Timeslot);
            objCmd.Parameters.AddWithValue("@dayname", objAM.Availableforday);

            objCmd.Parameters.Add("@activityid", SqlDbType.Int);
            objCmd.Parameters["@activityid"].Direction = ParameterDirection.Output;
            
            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            _activityid = Convert.ToInt32(objCmd.Parameters["@activityid"].Value);
            objCon.Close();
            return _activityid;
                    }

        public int CancelBookingDAL(int _bookingid)
        {
            int flag;
            SqlCommand objCmd = new SqlCommand("sp_cancelbooking", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@bookingid", _bookingid);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;

            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);
            objCon.Close();
            return flag;
        }

    }
}
