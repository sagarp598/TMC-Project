﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace LoginFunctionalityDAL
{
    public class LoginDAL
    {
        UserValOutput objUserValOP = new UserValOutput();
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString) ;
        int flag;
        public UserValOutput ValidateUserDAL (LoginEntity objL)
        {
            SqlCommand objCmd = new SqlCommand("sp_validateUser", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@username", objL.userName);
            objCmd.Parameters.AddWithValue("@password", objL.password);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;
            
            objCmd.Parameters.Add("@userid", SqlDbType.Int);
            objCmd.Parameters["@userid"].Direction = ParameterDirection.Output;

            objCmd.Parameters.Add("@isadmin", SqlDbType.Bit);
            objCmd.Parameters["@isadmin"].Direction = ParameterDirection.Output;

            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            objUserValOP.flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);
            objUserValOP.userid = Convert.ToInt32(objCmd.Parameters["@userid"].Value);
            objUserValOP.isadmin = Convert.ToBoolean(objCmd.Parameters["@isadmin"].Value);

            return objUserValOP;

        }

        public int CreateUser(UserRegistration objUR)
        {
            SqlCommand objCmd = new SqlCommand("sp_createUser", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@username", objUR.Username);
            objCmd.Parameters.AddWithValue("@password", objUR.Password);
            objCmd.Parameters.AddWithValue("@salutation",objUR.Salutation);
            objCmd.Parameters.AddWithValue("@fname", objUR.Fname);
            objCmd.Parameters.AddWithValue("@lname", objUR.Lname);
            objCmd.Parameters.AddWithValue("@institutionname", objUR.Institutionname);
            objCmd.Parameters.AddWithValue("@contactpersonname", objUR.Contactpersonname);
            objCmd.Parameters.AddWithValue("@custtype", objUR.Custtype);
            objCmd.Parameters.AddWithValue("@emailid", objUR.Emailid);
            objCmd.Parameters.AddWithValue("@contactno", objUR.Contactno);
            objCmd.Parameters.AddWithValue("@mobileno", objUR.Mobileno);
            objCmd.Parameters.AddWithValue("@address", objUR.Address);
            objCmd.Parameters.AddWithValue("@city", objUR.City);
            objCmd.Parameters.AddWithValue("@pincode", objUR.Pincode);
            objCmd.Parameters.AddWithValue("@isAdmin", objUR.IsAdmin);
            objCmd.Parameters.AddWithValue("@isVIP", objUR.IsVIP);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;
            
            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);


            return flag;

        }
    }
}
