﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessEntityDLL;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace LoginFunctionalityDAL
{
    public class LoginDAL
    {
        UserValOutput objUserValOP = new UserValOutput();
        SqlConnection objCon = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString) ;
        int flag;
        public UserValOutput ValidateUserDAL (LoginEntity objL)
        {
            SqlCommand objCmd = new SqlCommand("sp_validateUser", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@username", objL.userName);
            objCmd.Parameters.AddWithValue("@password", objL.password);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;
            
            objCmd.Parameters.Add("@userid", SqlDbType.Int);
            objCmd.Parameters["@userid"].Direction = ParameterDirection.Output;

            objCmd.Parameters.Add("@isadmin", SqlDbType.Bit);
            objCmd.Parameters["@isadmin"].Direction = ParameterDirection.Output;

            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            objUserValOP.flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);
            objUserValOP.userid = Convert.ToInt32(objCmd.Parameters["@userid"].Value);
            objUserValOP.isadmin = Convert.ToBoolean(objCmd.Parameters["@isadmin"].Value);

            return objUserValOP;

        }

        public int CreateUser(UserRegistration objUR)
        {
            SqlCommand objCmd = new SqlCommand("sp_createUser", objCon);
            objCmd.CommandType = CommandType.StoredProcedure;
            objCmd.Parameters.AddWithValue("@username", String.IsNullOrEmpty(objUR.Username) ? " " : objUR.Username);
            objCmd.Parameters.AddWithValue("@password", String.IsNullOrEmpty(objUR.Password) ? " " : objUR.Password);
            objCmd.Parameters.AddWithValue("@salutation",objUR.Salutation);
            objCmd.Parameters.AddWithValue("@fname", objUR.Fname);
            objCmd.Parameters.AddWithValue("@lname", objUR.Lname);
            objCmd.Parameters.AddWithValue("@institutionname", String.IsNullOrEmpty(objUR.Institutionname) ? " " : objUR.Institutionname);
            objCmd.Parameters.AddWithValue("@contactpersonname", String.IsNullOrEmpty(objUR.Contactpersonname) ? " " : objUR.Contactpersonname);
            objCmd.Parameters.AddWithValue("@custtype",String.IsNullOrEmpty(objUR.Custtype) ? " " : objUR.Custtype); 
            objCmd.Parameters.AddWithValue("@emailid",String.IsNullOrEmpty(objUR.Emailid) ? " " : objUR.Emailid);
            objCmd.Parameters.AddWithValue("@contactno",String.IsNullOrEmpty(objUR.Contactno) ? " " : objUR.Contactno  );
            objCmd.Parameters.AddWithValue("@mobileno",String.IsNullOrEmpty(objUR.Mobileno) ? " " : objUR.Mobileno   );
            objCmd.Parameters.AddWithValue("@address",String.IsNullOrEmpty(objUR.Address) ? " " : objUR.Address    );
            objCmd.Parameters.AddWithValue("@city",String.IsNullOrEmpty(objUR.City) ? " " : objUR.City       );
            objCmd.Parameters.AddWithValue("@pincode", String. IsNullOrEmpty(Convert.ToString(objUR.Pincode)) ? 0 : objUR.Pincode    );
            objCmd.Parameters.AddWithValue("@isAdmin", 0);
            objCmd.Parameters.AddWithValue("@isVIP",  objUR.IsVIP);
            objCmd.Parameters.AddWithValue("@designation", String.IsNullOrEmpty(objUR.Designation) ? " " : objUR.Designation);

            objCmd.Parameters.Add("@flag", SqlDbType.Int);
            objCmd.Parameters["@flag"].Direction = ParameterDirection.Output;
            
            objCmd.Connection = objCon;
            objCon.Open();
            int i = objCmd.ExecuteNonQuery();
            flag = Convert.ToInt32(objCmd.Parameters["@flag"].Value);


            return flag;

        }
    }
}
