﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginFuncationality_BAL;
using BusinessEntityDLL;

namespace LoginFunctionality
{
    public partial class Login : System.Web.UI.Page
    {
        UserValOutput objUserValOP = new UserValOutput();
        LoginEntity objLogin = new LoginEntity(); //Entity object
        LoginBAL objLoginBAL = new LoginBAL();
        

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            
            objLogin.userName = txtboxUsername.Text;
            objLogin.password = txtboxPassword.Text;
            objUserValOP = objLoginBAL.ValidateUser(objLogin);

            switch(objUserValOP.flag)
            {
                case 0: lblMsg.Text = "User is not registered. Please Sign Up."; break;
                case 1: lblMsg.Text = "Incorrect username or password";break;
                case 2: Session["username"] = txtboxUsername.Text; Session["userid"] = objUserValOP.userid;
                    if (objUserValOP.isadmin == false)
                    {
                        Response.Redirect("~/Home.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/AdminHome.aspx");
                    } ;

                    break;
                default: break;
            }
            
            

        }
    }
}