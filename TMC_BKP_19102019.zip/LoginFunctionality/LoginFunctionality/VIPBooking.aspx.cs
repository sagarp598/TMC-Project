﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using LoginFuncationality_BAL;
using BusinessEntityDLL;

namespace LoginFunctionality
{
    public partial class VIPBooking : System.Web.UI.Page
    {
        List<GetAllVIP> lstVIP = new List<GetAllVIP>();
        AdminBAL objBAL = new AdminBAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            { LoadVIPDDL(); }
        }

        protected void btnAddVIP_Click(object sender, EventArgs e)
        {
            pnlVIP.Visible = true;
        }

        public void LoadVIPDDL()
        {
            lstVIP = objBAL.GetAllVIPBAL();
            ddlVIPNames.DataSource = lstVIP;
            ddlVIPNames.DataTextField = "VIPName";
            ddlVIPNames.DataValueField = "UserId";
            ddlVIPNames.DataBind();
        }

        protected void btnRegister_Click(object sender, EventArgs e)
        {
            LoginBAL objLoginBal = new LoginBAL();
            int flag;
            BusinessEntityDLL.UserRegistration objUserReg = new BusinessEntityDLL.UserRegistration();
            objUserReg.Username = "VIP-" + txtFname.Text + " " + txtLname.Text;
            objUserReg.Salutation = ddlSalutation.SelectedValue.ToString();
            objUserReg.Fname = txtFname.Text;
            objUserReg.Lname = txtLname.Text;
            objUserReg.Contactno = txtContNo.Text;
            objUserReg.Mobileno = txtMobNo.Text;
            objUserReg.Address = txtAddress.Text;
            objUserReg.IsVIP = true;
            objUserReg.Designation = txtDesignation.Text;

            flag = objLoginBal.CreateUser(objUserReg);

            if (flag == 0)
            {
                lblStatus.Text = "User Resgistration is successful!!. Please select VIP Person from list.";
                Reset();
                //LoadVIPDDL();
                //pnlVIP.Visible = false;
                Response.Redirect("~/VIPBooking.aspx");
            }
            else
            {
                lblStatus.Text = "User Resgistration is failed.Contact System Admin.";
                Reset();
                pnlVIP.Visible = false;
            }
        }

        public void Reset()
        {
            
            ddlSalutation.SelectedIndex = 0;
            txtFname.Text = "";
            txtLname.Text = "";
            txtContNo.Text = "";
            txtMobNo.Text = "";
            txtAddress.Text = "";
            txtDesignation.Text = "";
            


        }

        protected void btnCreateBooking_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Booking.aspx?uid=" + ddlVIPNames.SelectedValue + "&ad=1");
        }
    }
}