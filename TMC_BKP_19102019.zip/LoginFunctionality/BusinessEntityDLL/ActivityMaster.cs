﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class ActivityMaster
    {
        private int _activity_id;
        private string _activityname;
        private string _categoryname;
        private string _timeslot;
        private int _quantityno;
        private string _availableforday;
        private string _selecteddate;

        public int Activity_id
        {
            get { return _activity_id; }
            set { _activity_id = value; }
        }
        public string Activityname
        {
            get { return _activityname; }
            set { _activityname = value; }
        }
        public string Categoryname
        {
            get { return _categoryname; }
            set { _categoryname = value; }
        }
        public string Timeslot
        {
            get { return _timeslot; }
            set { _timeslot = value; }
        }
        public int Quantityno
        {
            get { return _quantityno; }
            set { _quantityno = value; }
        }
        public string Availableforday
        {
            get { return _availableforday; }
            set { _availableforday = value; }
        }

        public string SelectedDate
        {
            get { return _selecteddate; }
            set { _selecteddate = value; }
        }

    }
}
