﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class GetAllVIP
    {

        
        private int _userid;
        private string _vipname;
        
        public int UserId
        {
            get { return _userid; }
            set { _userid = value; }
        }
        public string VIPName
        {
            get { return _vipname; }
            set { _vipname = value; }
        }

    }
}
