﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class BookingStatusView
    {
        private int _bookingid;
        private string _activityname;
        private string _categoryname;
        private string _timeslot;
        private int _quantityno;
        private string _bookingdate;
        private string _bookingplaceddate;
        private string _bookingstatus;
        private string _remarks;

        public int BookingId
        {
            get { return _bookingid; }
            set { _bookingid = value; }
        }

        public string Activityname
        {
            get { return _activityname; }
            set { _activityname = value; }
        }
        public string Categoryname
        {
            get { return _categoryname; }
            set { _categoryname = value; }
        }
        public string Timeslot
        {
            get { return _timeslot; }
            set { _timeslot = value; }
        }
        public int Quantityno
        {
            get { return _quantityno; }
            set { _quantityno = value; }
        }
        public string BookingDate
        {
            get { return _bookingdate; }
            set { _bookingdate = value; }
        }

        public string BookingPlacedDate
        {
            get { return _bookingplaceddate; }
            set { _bookingplaceddate = value; }
        }

        public string BookingStatus
        {
            get { return _bookingstatus; }
            set { _bookingstatus = value; }
        }
        public string Remarks
        {
            get { return _remarks; }
            set { _remarks = value; }
        }

    }
}
