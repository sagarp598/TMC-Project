﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntityDLL
{
    public class CreateBooking
    {
        
        private int _userid;
        private int _activityid;
        private int _quantityno;
        private string _bookingdate;
        private string _bookingstatus;
        private string _bookingupdatedby;

                                           
        public int UserId
        {
            get { return _userid; }
            set { _userid = value; }
        }

        public int ActivityId
        {
            get { return _activityid; }
            set { _activityid = value; }
        }

        public int QuantityNo
        {
            get { return _quantityno; }
            set { _quantityno = value; }
        }
        public string BookingDate
        {
            get { return _bookingdate; }
            set { _bookingdate = value; }
        }
        public string BookingStatus
        {
            get { return _bookingstatus; }
            set { _bookingstatus = value; }
        }
        public string BookingUpdatedBy
        {
            get { return _bookingupdatedby; }
            set { _bookingupdatedby = value; }
        }
       

    
        


    }
}
